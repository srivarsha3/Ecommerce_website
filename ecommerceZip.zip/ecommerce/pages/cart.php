<?php
session_start();
include '../includes/db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle Add To Cart
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];

    // Check if product already in cart
    $stmt = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $stmt->execute([$user_id, $product_id]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        // If already in cart, increase quantity
        $newQty = $existing['quantity'] + 1;
        $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
        $stmt->execute([$newQty, $existing['id']]);
    } else {
        // Otherwise insert a new cart row
        $stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)");
        $stmt->execute([$user_id, $product_id]);
    }

    // Redirect back to index or cart so refresh doesn’t resubmit
    header("Location: cart.php");
    exit();
}

// Remove item
if (isset($_POST['remove_from_cart'])) {
    $cart_id = $_POST['cart_id'];
    $stmt = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $stmt->execute([$cart_id, $user_id]);
    header("Location: cart.php");
    exit();
}

// Update quantity
if (isset($_POST['update_quantity'])) {
    $cart_id = $_POST['cart_id'];
    $quantity = (int)$_POST['quantity'];
    if ($quantity > 0) {
        $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$quantity, $cart_id, $user_id]);
    }
    header("Location: cart.php");
    exit();
}

// Fetch cart items
$stmt = $conn->prepare("
    SELECT cart.id AS cart_id,
           products.name,
           products.price,
           cart.quantity
    FROM cart
    JOIN products ON cart.product_id = products.id
    WHERE cart.user_id = ?
");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_cost = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Cart</title>
    <style>
        body { font-family: Arial, sans-serif; background: #eef2f5; padding: 20px;}
        .cart-container { max-width: 900px; margin:auto; background:#fff; padding:25px; border-radius:8px; }
        table { width:100%; border-collapse:collapse; }
        th, td { padding:12px; border-bottom:1px solid #ccc; text-align:center; }
        th { background:#f7f7f7; }
        input[type="number"] { width:60px; padding:5px; }
        button { padding:8px 12px; border:none; border-radius:4px; cursor:pointer; }
        .update-btn { background:#007bff; color:#fff; }
        .remove-btn { background:#cc0000; color:#fff; }
        .total { text-align:right; font-size:1.3em; padding:10px 0; }
        .checkout a { padding:10px 18px; background:#28a745; color:#fff; text-decoration:none; border-radius:5px; }
    </style>
</head>
<body>
<div class="cart-container">
    <h2>Your Shopping Cart</h2>

    <?php if (empty($cart_items)): ?>
        <p>Your cart is empty.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
                <th>Action</th>
            </tr>

            <?php foreach ($cart_items as $item): ?>
                <?php $subtotal = $item['price'] * $item['quantity']; $total_cost += $subtotal; ?>
                <tr>
                    <td><?= htmlspecialchars($item['name']); ?></td>
                    <td>$<?= number_format($item['price'],2); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="cart_id" value="<?= $item['cart_id']; ?>">
                            <input type="number" name="quantity" value="<?= $item['quantity']; ?>" min="1">
                            <button type="submit" name="update_quantity" class="update-btn">Update</button>
                        </form>
                    </td>
                    <td>$<?= number_format($subtotal,2); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="cart_id" value="<?= $item['cart_id']; ?>">
                            <button type="submit" name="remove_from_cart" class="remove-btn">Remove</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>

        <div class="total"><strong>Total: $<?= number_format($total_cost,2); ?></strong></div>
        <div class="checkout"><a href="checkout.php">Proceed to Checkout</a></div>
    <?php endif; ?>
</div>
</body>
</html>
